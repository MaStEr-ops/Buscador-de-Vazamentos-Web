#Importaando bibliotecas
from funcFiltroDeDados import removendoDuplicadas
from funcaos import buscaWeb, analiseArquivos
from time import sleep

#definindo variáveis
busca_web="0"
metodos="0"


#Logo
print("""|----------------------------------------------------------------------------------------------|
|----------------------------------------------------------------------------------------------|
 |                                                                                            |
 |    ||||||||||      /||\      /||||||||\  |||         ||||||||||                            |
 |    |||            /|  |\     |||         |||         |||                                   |
 |    ||||||||||    /||||||\    |||  ||||\  |||         ||||||||||                            |
 |    |||          /|      |\   |||    |||  |||         |||                                   |
 |    ||||||||||  /|        |\  \||||||||/  ||||||||||  ||||||||||                            |
 |                                                                                            |
 |                                     \033[31m               /|||||||||  ||||||||||  /||||||||\  \033[0;0m    |
 |                                     \033[31m               |||         |||         |||    |||  \033[0;0m    |
 |                                     \033[31m               \||||||||\  ||||||||||  |||         \033[0;0m    |
 |                                     \033[31m                      |||  |||         |||    |||  \033[0;0m    |
 |                                     \033[31m               |||||||||/  ||||||||||  \||||||||/  \033[0;0m    |
 |                                                                                            |
|----------------------------------------------------------------------------------------------|
|----------------------------------------------------------------------------------------------|\n\n\n""")


while metodos != "3":
    #Menu
    metodos=input("-"*40+"\n[1]-[ Busca de dados na Web ]\n\n[2]-[ Análise de Arquivos   ]\n\n[3]-[ Sair                  ]\n"+"-"*40+"\n\nR: ")

    #Busca de dados
    if metodos == "1":
        buscaWeb()
        removendoDuplicadas()

    #Análise de arquivos
    elif metodos == "2":
        analiseArquivos()

    #Sair
    elif metodos == "3":
        print("\n Saindo...")
        sleep(3)

    else:
        print("\n\033[31m### Opção não encontrada ###\n\033[0;0m")
        sleep(3)

