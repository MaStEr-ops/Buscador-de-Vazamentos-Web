#importando biblioteca
import time
import datetime
import tqdm

# Definindo variaveis
datahora = datetime.datetime.now()

nomedoarquivo='Bruto'+(datahora.strftime('%d_%m_%Y-%H_%M')+'.txt')
global bruto
bruto=nomedoarquivo

nomedoarquivo='logURLs'+(datahora.strftime('%d_%m_%Y-%H_%M')+'.txt')
global logURLs
logURLs=nomedoarquivo

nomedoarquivo='link'+(datahora.strftime('%d_%m_%Y-%H_%M')+'.txt')
global link
link=nomedoarquivo


#Criando a função filtro
def filtro(analise):

    with open('arquivos/Bruto/' + bruto, 'w') as arquivo:
        arquivo.close()

    time.sleep(1)
    
    for link in analise.find_all('a')[:100]:

        with open('arquivos/Bruto/'+bruto, 'r') as arquivo:
            conteudo = arquivo.readlines()
            conteudo.append(link.get('href')+'#')

        with open('arquivos/Bruto/'+bruto, 'w') as arquivo:
            arquivo.writelines(conteudo)
            arquivo.close()


    #Lendo um arquivo .txt e fazendo uma quebra na frase onde contém #
    with open('arquivos/Bruto/'+bruto, "r", encoding="utf-8") as arquivo:
        conteudo = arquivo.read().split("#")

    #Adicionando quebra de linha no conteúdo do arquivo
    with open('arquivos/Bruto/'+bruto, "w", encoding="utf-8") as arquivo:
        for linha in conteudo:
            arquivo.write(f'{linha}\n')

    #Lendo um arquivo .txt e fazendo uma quebra na frase onde contém &
    with open('arquivos/Bruto/'+bruto, "r", encoding="utf-8") as arquivo:
        conteudo = arquivo.read().split("&")

    #Adicionando quebra de linha no conteúdo do arquivo
    with open('arquivos/Bruto/'+bruto, "w", encoding="utf-8") as arquivo:
        for linha in conteudo:
            arquivo.write(f'{linha}\n')


def arquivoLeak():

    #Criando um arquivo .txt
    with open('arquivos/Diversos/' + link, 'w') as arquivo:
        arquivo.close()
        
    time.sleep(1)
    with open('arquivos/Bruto/'+bruto, "r", encoding="utf-8") as arquivo:
        for linha in arquivo:
            linha = linha.rstrip()
            if "url" in linha:
                with open('arquivos/Diversos/'+link, 'r') as arquivo:
                    conteudo = arquivo.readlines()
                    conteudo.append(linha+'#')
                with open('arquivos/Diversos/'+link, 'w') as arquivo:
                    arquivo.writelines(conteudo)
                    arquivo.close()

    #Lendo um arquivo .txt e fazendo uma quebra na frase onde contém #
    with open('arquivos/Diversos/'+link, "r", encoding="utf-8") as arquivo:
        conteudo = arquivo.read().split("#")

    #Adicionando quebra de linha no conteúdo do arquivo
    with open('arquivos/Diversos/'+link, "w", encoding="utf-8") as arquivo:
        for linha in conteudo:
            arquivo.write(f'{linha}\n')

def removendoDuplicadas():

    with open('arquivos/Diversos/'+link) as input:
        unique =set(line.rstrip('\n') for line in input)
    with open("arquivos/LogURL/"+logURLs, 'w') as output:
        for line in unique:
            output.write(line)
            output.write('\n')
    print("\n\033[1;32mProcedimento concluído.\033[0;0m\n")