#Importando biblioteca
from time import sleep

#Importando funções
import funcFiltroDeDados
import funcGoogle

#Análise de arquivos
#Criando função analiseArquivo()
def analiseArquivos():
    print("\n--Análise de arquivos--\n")
    nome_arq = input("\nNome do Arquivo: ")
    nome_arq = ('arquivos/'+ nome_arq)
    busca_palavra = input("\nBusca: ")
    arquivo=open(nome_arq, 'r')
    contador=0
    for linha in arquivo:
        linha = linha.rstrip()
        if busca_palavra in linha:
            contador += 1
            print("\n"+linha)
    print("\nFoi encontrado", contador,"linha(s) com a palavra", busca_palavra,"\n")



#Busca Web
def buscaWeb():

    #definindo variáveis
#    local_Busca = 0
#    busca_web = 0


    print("\n\n---Busca Web---")
    print("\n")


    #Menu será escolhido um meio de busca
#    local_Busca = input("-" * 40 + "\n[1]-Google\n[2]-Bing\n[3]-Yahoo\n"+"-" * 40 + "\n\nR: ")

    #Google
#    if local_Busca=="1":
#        local_Busca_Escolhido=funcGoogle

    #Bing
#    elif local_Busca=="2":
#        local_Busca_Escolhido=funcBing

    #Yahoo
#    elif local_Busca=="3":
#        local_Busca_Escolhido=funcYahoo

    #--------------------------------------------------------------------------------------------------

    busca = input("Busca: ")
    print("\n")


    #Busca de termos presentes na URL
    palavra_chave=("inurl:"+busca)
    funcGoogle.urls(palavra_chave)

    funcFiltroDeDados.arquivoLeak()
    


    #Busca por título de páginas
    palavra_chave = ("intitle:" + busca)
    funcGoogle.urls(palavra_chave)

    funcFiltroDeDados.arquivoLeak()
    

    #Busca por texto no conteúdo do site
    palavra_chave = ("intext:" + busca)
    funcGoogle.urls(palavra_chave)

    funcFiltroDeDados.arquivoLeak()
    
