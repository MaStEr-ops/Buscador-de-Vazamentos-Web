#Importando bibliotecas
import requests
from bs4 import BeautifulSoup

#Importando funções
import funcFiltroDeDados


#Criando função urls()
def urls(plavra_chave):
    buscando =requests.get("https://www.bing.com/search?q="+ plavra_chave)
    analise=BeautifulSoup(buscando.text, "html.parser")

    funcFiltroDeDados.filtro(analise)